/**
 * 
 * @author Antony Jeganthan
 *
 */
public enum CellType {
	wall, floor, box, goal, player, test, start, fault, removed 
}
