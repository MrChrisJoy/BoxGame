import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.PriorityQueue;

/**
 * 
 * @author Antony Jeganathan
 *
 */
public class AStar {
	private int mazeSize;
	private CellOfMaze[][] maze;
	private Comparator<State> comparator;
	private ArrayList<State> visitedStates;
	
	public AStar(CellOfMaze[][] maze, int size) {
		mazeSize = size;
		this.maze = maze;
		comparator = new StateComparator();
		visitedStates = new ArrayList<State>();
	}
	
	public ArrayList<CellOfMaze> findPath(CellOfMaze start, CellOfMaze finish) {
		// check if both inputs arnt null
		if(start == null){
			System.out.println("start location is null");
		}else if(finish == null) {
			System.out.println("finish location is null");
		}
		
		//System.out.println("Strt (" + start.getX() + "," + start.getY()+")");
		//System.out.println("Goal (" + finish.getX() + "," + finish.getY()+")");
		
		ArrayList<CellOfMaze> path = new ArrayList<CellOfMaze>();
		PriorityQueue<State> queue = new PriorityQueue<State>(comparator);
		int statesRemoved = 0;
		State startState = new State(0,start,getPossibleAdjCells(start),null);
		queue.add(startState);
		boolean found = false;
		
		while(!queue.isEmpty()) {
			State state = queue.poll();
		//	System.out.println("Removeed cell: "+state.getCell().getX() +","+ state.getCell().getY());
			statesRemoved++;
			
			
			if(!hasVisited(state,visitedStates)) {
				visitedStates.add(state);
				state.getCell().setVisited();
				//System.out.println("Not Visited ");
				
				if(getCostToDestination(state.getCell(),finish) == 1) {
					//System.out.println("Finished");
					//System.out.print("col = " + state.getCell().getX() +" row = " + state.getCell().getY() + " Status " + state.getCell().getStatus());
					while(state != null) {
						path.add(state.getCell());
						state = state.getParent();
					}
					found = true;
				} else {
				
					ArrayList<CellOfMaze> possibleAdjCells = getPossibleAdjCells(state.getCell());
					//System.out.print("col = " + state.getCell().getX() +" row = " + state.getCell().getY() + " Status " + state.getCell().getStatus());
					//System.out.println(" Number of Possible Cells: " + possibleAdjCells.size());	
					
					CellOfMaze selected = selectedCell(possibleAdjCells,finish);
					
					if( !possibleAdjCells.isEmpty()) {
						//System.out.println("Cost to dest from Select: " + +getCostToDestination(selected,finish));
						//System.out.println("Add cell: "+selected.getX() +","+ selected.getY());
						for(CellOfMaze cell: possibleAdjCells){
							int newTotalCost = state.getTotalCost() + 1; 
							queue.add(new State(newTotalCost,cell,getPossibleAdjCells(cell), state));
						}
					}
				}
			}
			if(found) {
				Collections.reverse(path);
				for(CellOfMaze pathCell: path) {
					//System.out.print("("+pathCell.getX()+","+pathCell.getY()+") ");
					//maze[pathCell.getX()][pathCell.getY()].setStatus(CellType.test);
				}
				//System.out.println(" Path Length "+path.size());
				break;
			}
		}	
		
		if(queue.isEmpty() && !found){
			System.out.println("PAth is not found");
			//maze[start.getX()][start.getY()].setStatus(CellType.fault);
			//maze[finish.getX()][finish.getY()].setStatus(CellType.fault);
		}
		
		for (int r=0;r < mazeSize;r++){
			for(int c=0;c< mazeSize;c++){
				maze[c][r].setUnVisited();;					
			}
		}
		return path;
	}

	private boolean hasVisited(State currState, ArrayList<State> visitedStates) {
		boolean visited = false;
		//System.out.println("visited State " + visitedStates.size());
		for(State state: visitedStates) {
			if(state.getCell().getX() == currState.getCell().getX() && 
					state.getCell().getY() == currState.getCell().getY()) {
				visited = false;
				for(CellOfMaze cell: currState.getAdjCells()){
					if(cell.hasVisited()){
						visited = true;
					}
				}
			}
		}
		return visited;
	}

	private CellOfMaze selectedCell(ArrayList<CellOfMaze> possibleAdjCells, CellOfMaze finish) {
		int cost = 0;
		int prevCost = 0;
		CellOfMaze cell = null;
		//getCostToDestination(possibleAdjCells.get(0),finish);
		for(CellOfMaze currCell: possibleAdjCells) {
			if(!currCell.hasVisited()){
				prevCost = getCostToDestination(currCell,finish);
				//System.out.println(" Cost to of selected: " + prevCost);
				if(cost == 0){
					cell = currCell;
					cost = prevCost;
				}else if(prevCost <= cost) {
					cell = currCell;
					cost = prevCost;
				}
			}
		}
		return cell;
	}

	private int getCostToDestination(CellOfMaze start, CellOfMaze finish) {
		return Math.abs(start.getX() - finish.getX()) + Math.abs(start.getY() - finish.getY());
	}

	private ArrayList<CellOfMaze> getPossibleAdjCells(CellOfMaze cell) {
		// x<- col  y<- row
		ArrayList<CellOfMaze> possibleCells = new ArrayList<CellOfMaze>();
		int x = cell.getX();
		int y = cell.getY();
		//Check this for edge cases
		if(y == mazeSize-1) {
			if(maze[x+1][y].getStatus().equals(CellType.floor) || maze[x+1][y].getStatus().equals(CellType.player)){
				if(!maze[x+1][y].hasVisited()){
					possibleCells.add(maze[x+1][y]);
				}
			}
			if(maze[x-1][y].getStatus().equals(CellType.floor)  || maze[x-1][y].getStatus().equals(CellType.player)){
				if(!maze[x-1][y].hasVisited()){
					possibleCells.add(maze[x-1][y]);
				}
			}
			if(maze[x][y-1].getStatus().equals(CellType.floor)  || maze[x][y-1].getStatus().equals(CellType.player)){
				if(!maze[x][y-1].hasVisited()){
					possibleCells.add(maze[x][y-1]);
				}
			}
		}else {
		
			if(maze[x][y+1].getStatus().equals(CellType.floor)  || maze[x][y+1].getStatus().equals(CellType.player)){
				if(!maze[x][y+1].hasVisited()){
					possibleCells.add(maze[x][y+1]);
				}
			}
			if(maze[x][y-1].getStatus().equals(CellType.floor)  || maze[x][y-1].getStatus().equals(CellType.player)){
				if(!maze[x][y-1].hasVisited()){
					possibleCells.add(maze[x][y-1]);
				}
			}		
			if(maze[x+1][y].getStatus().equals(CellType.floor)  || maze[x+1][y].getStatus().equals(CellType.player)){
				if(!maze[x+1][y].hasVisited()){
					possibleCells.add(maze[x+1][y]);
				}
			}
			if(maze[x-1][y].getStatus().equals(CellType.floor)  || maze[x-1][y].getStatus().equals(CellType.player)){
				if(!maze[x-1][y].hasVisited()){
					possibleCells.add(maze[x-1][y]);
				}
			}		
		
		}
		return possibleCells;
	}
	
	
}
